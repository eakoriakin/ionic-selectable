import { Component, Prop, h, Host, ComponentInterface, State, Element, FunctionalComponent } from '@stencil/core';
import '@ionic/core';
import { CssClassMap, getMode,  } from '@ionic/core';
import { hostContext } from '../../utils/utils';

@Component({
  tag: 'ionic-selectable',
  styleUrl: 'ionic-selectable.component.scss',
  shadow: true
})
export class IonicSelectableComponent implements ComponentInterface {

  private inputId = `ion-sel-${selectIds++}`;
  private buttonEl?: HTMLButtonElement;

   /**
   * If `true`, the user cannot interact with the select.
   */
  @Prop() disabled = false;

  @Element() el!: HTMLIonSelectElement;

  @State() isExpanded = false;

  /**
   * The name of the control, which is submitted with the form data.
   */
  @Prop() name: string = this.inputId;

  /**
   * The text to display when the select is empty.
   */
  @Prop() placeholder?: string | null;

  /**
   * the value of the select.
   */
  @Prop({ mutable: true }) value?: any | null;

  @Prop() renderIcon?: FunctionalComponent;

  private onClick = (ev: UIEvent) => {
    // this.setFocus();
    // this.open(ev);
  }

  public render(): void {
    const { placeholder, name, disabled, isExpanded, value, el } = this;
    const mode = getMode();
    const labelId = this.inputId + '-lbl';
    const label = null//findItemLabel(el);
    if (label) {
      label.id = labelId;
    }
    let addPlaceholderClass = false;
    let selectText = ''; //this.getText();
    if (selectText === '' && placeholder != null) {
      selectText = placeholder;
      addPlaceholderClass = true;
    }

    const selectTextClasses: CssClassMap = {
      'select-text': true,
      'select-placeholder': addPlaceholderClass
    };
    return (
/*       <Host>
        <div class="ionic-selectable-inner">
          <div class="ionic-selectable-value">
            <div class="ionic-selectable-value-item">Item</div>
          </div>
          <div class="ionic-selectable-icon">
            <ion-icon name="caret-down-outline" />
          </div>
      1    <button class="ionic-selectable-cover" type="button" />
        </div>
      </Host> */
      <Host
      onClick={this.onClick}
      role="combobox"
      aria-haspopup="dialog"
      aria-disabled={disabled ? 'true' : null}
      aria-expanded={`${isExpanded}`}
      aria-labelledby={labelId}
      class={{
        [mode]: true,
        'in-item': hostContext('ion-item', el),
        'select-disabled': disabled,
      }}
    >
      <div class={selectTextClasses} part="text">
        {selectText}
      </div>
      <div class="select-icon" role="presentation" part="icon">
        <div class="select-icon-inner"></div>
        <renderIcon></renderIcon>
      </div>
      <button
        type="button"
        // onFocus={this.onFocus}
        // onBlur={this.onBlur}
        disabled={disabled}
        ref={(btnEl => this.buttonEl = btnEl)}
      >
      </button>
    </Host>
    );
  }
}
let selectIds = 0;


interface HelloProps {
  name: string;
}

const Hello: FunctionalComponent<HelloProps> = ({ name }) => (
  <h1>Hello, {name}!</h1>
);
